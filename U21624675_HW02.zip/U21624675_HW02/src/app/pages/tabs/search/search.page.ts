import { Component, OnInit, ViewChild } from '@angular/core';
import { Restaurant } from 'src/app/models/restaurant.model';
import { ApiService } from 'src/app/services/api/api.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.page.html',
  styleUrls: ['./search.page.scss'],
})
export class SearchPage implements OnInit {

  @ViewChild('searchInput') sInput;
  model: any = {
  
    title: 'SEARCH'
  };
  isLoading: boolean = false;
  query: string = '';
  allRestaurants: Restaurant[] = [];
  restaurants: Restaurant[] = [];

  constructor(private api: ApiService) { }

  ngOnInit() {
    
    this.loadRestaurants();
  }

  async loadRestaurants() {
    this.isLoading = true;
    try {
      this.allRestaurants = await this.api.allRestaurants;
    } catch (error) {
      console.error('Error loading :', error);
    } finally {
      this.isLoading = false;
      
      setTimeout(() => {
        this.sInput.setFocus();
      }, 500);
    }
  }

  async onSearchChange(event) {
    this.query = event.detail.value.trim().toLowerCase();
    if (this.query.length > 0) {
      this.isLoading = true;
      try {
        
        this.restaurants = this.allRestaurants.filter((restaurant: Restaurant) => {
          return restaurant.short_name.toLowerCase().includes(this.query);
        });
      } catch (error) {
        console.error('Error', error);
      } finally {
        this.isLoading = false;
      }
    } else {
      this.restaurants = []; 
    }
  }
}


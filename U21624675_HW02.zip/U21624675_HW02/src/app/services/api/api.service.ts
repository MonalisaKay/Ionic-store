import { Injectable } from '@angular/core';
import { Address } from 'src/app/models/address.model';
import { Category } from 'src/app/models/category.model';
import { Item } from 'src/app/models/item.model';
import { Order } from 'src/app/models/order.model';
import { Restaurant } from 'src/app/models/restaurant.model';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  banners = [  
    {banner: 'assets/imgs/3.jpg'},
    {banner: 'assets/imgs/2.jpg'},
    {banner: 'assets/imgs/1.jpg'}  
  ];
  
  restaurants: Restaurant[] = [
    {
      uid: '12wefdss',
      cover: 'assets/imgs/1.jpg',
      name: 'Forti n Grill',
      short_name: 'Forti n Grill',
      cuisines: [
        'French'
      ],
      rating: 4.5,
      delivery_time: 50,
      distance: 2,
      price: 200
    },
    {
      uid: '12wefdefsdss',
      cover: 'assets/imgs/2.jpg',
      name: 'KUNG-FU Kitchen',
      short_name: 'KUNG-FU Kitchen',
      cuisines: [
        'Asian'
      ],
      rating: 4,
      delivery_time: 45,
      distance: 2,
      price: 180
    },
    {
      uid: '12wefdssrete',
      cover: 'assets/imgs/3.jpg',
      name: 'SMOKE Hazelwood',
      short_name: 'SMOKE Hazelwood',
      cuisines: [
        'Greek'
      ],
      rating: 5,
      delivery_time: 40,
      distance: 3,
      price: 150
    },
  ];

  allRestaurants: Restaurant[] = [
    {
      uid: '12wefdss',
      cover: 'assets/imgs/1.jpg',
      name: 'Forti n Grill',
      short_name: 'Forti n Grill',
      cuisines: [
        'French'
      ],
      rating: 4.5,
      delivery_time: 50,
      distance: 2,
      price: 200
    },
    {
      uid: '12wefdefsdss',
      cover: 'assets/imgs/2.jpg',
      name: 'KUNG-FU Kitchen',
      short_name: 'KUNG-FU Kitchen',
      cuisines: [
        'Asian'
      ],
      rating: 4,
      delivery_time: 45,
      distance: 2,
      price: 180
    },
    {
      uid: '12wefdssrete',
      cover: 'assets/imgs/3.jpg',
      name: 'SMOKE Hazelwood',
      short_name: 'SMOKE Hazelwood',
      cuisines: [
        'Greek'
      ],
      rating: 5,
      delivery_time: 40,
      distance: 3,
      price: 150
    },
  ];

  restaurants1: Restaurant[] = [
    {
      uid: '12wefdss',
      cover: 'assets/imgs/1.jpg',
      name: 'Forti n Grill',
      short_name: 'Forti n Grill',
      address: '245 Hazelwood',
      cuisines: [
        'French'
      ],
      rating: 4.5,
      delivery_time: 50,
      distance: 2,
      price: 200
    },
    {
      uid: '12wefdefsdss',
      cover: 'assets/imgs/2.jpg',
      name: 'KUNG-FU Kitchen',
      short_name: 'KUNG-FU Kitchen',
      cuisines: [
        'Asian'
      ],
      rating: 4.0,
      delivery_time: 5,
      address: '111 Hazelwood',
      distance: 1.5,
      price: 100
    },
    {
      uid: '12wefdssrete',
      cover: 'assets/imgs/3.jpg',
      name: 'SMOKE Hazelwood',
      short_name: 'SMOKE Hazelwood',
      cuisines: [
        'Greek'
      ],
      rating: 4.7,
      delivery_time: 25,
      address: '265 Hazelwood',
      distance: 3,
      price: 150
    },
  ];
  
  categories: Category[] = [
    {
      id: "e0",
      name: "French",
      uid: "12wefdefsdss"
    },
    {
      id: "e00",
      name: "Asian",
      uid: "12wefdss"
    },
    {
      id: "e01",
      name: "Greek",
      uid: "12wefdssrete"
    },
    
    
  ]; 

  allItems: Item[] = [
    
    
    {
        category_id: "e0",
        cover: "assets/imgs/2.jpg",
        desc: "Tasty and Spicy",
        id: "i1",
        name: "Chow-Mein",
        price: 50,
        rating: 0,
        status: true,
        uid: "12wefdefsdss",
        variation: false,
        veg: false
    },
    {
      category_id: "e00",
      cover: "assets/imgs/1.jpg",
      desc: "Decadent",
      id: "i1",
      name: "Gourmet waffles",
      price: 75,
      rating: 0,
      status: true,
      uid: "12wefdss",
      variation: false,
      veg: false
  },
  {
    category_id: "e01",
    cover: "assets/imgs/3.jpg",
    desc: "Angels dancing on your tastebuds",
    id: "i1",
    name: "Beef stroganof",
    price: 55,
    rating: 0,
    status: true,
    uid: "12wefdssrete",
    variation: false,
    veg: false
},
   
  ];

  addresses: Address[] = [     
    {
      address: "Tuks Village", 
      house: "Block A", 
      id: "7Kox63KlggTvV7ebRKar", 
      landmark: "TuksRes", 
      lat: 56.75855, 
      lng: 34.555777, 
      title: "Home", 
      user_id: "1"},
    {address: "UniCrest", house: "Unit 456", id: "8Kox63KlggTvV7ebRKar", landmark: "Tuksres", lat: 56.75855, lng: 34.555777, title: "Home", user_id: "1"}
  ];

  orders: Order[] = [      
    {
      address: {address: "Unicrest", house: "Unit A", id: "cLQdnS8YXk5HTDfM3UQC", landmark: "Lofts", lat: 26.108991978867923, lng: 91.79069981213378, title: "Home", user_id: "1" }, 
      deliveryCharge: 15,
      grandTotal: 200.00,
      id: "5aG0RsPuze8NX00B7uRP",
      order: [
        {category_id: "e0", cover: "assets/imgs/2.jpg", desc: "Tasty and Spicy", id: "i2", name: "Chow-Mein", price: 200, rating: 0, status: true, uid: "12wefdefsdss", variation: false, veg: true, quantity: 4},
      ],
      paid: "COD",  
      restaurant: 
     {
        uid: '12wefdefsdss',
        cover: 'assets/imgs/2.jpg',
        name: 'KUNG-FU Kitchen',
        short_name: 'KUNG-FU Kitchen',
        cuisines: [
          'Asian'
        ],
        rating: 4.0,
        delivery_time: 5,
        distance: 1.5,
        price: 100
      },
      restaurant_id: "12wefdefsdss",  
      status: "Delivered",
      time: "May 6, 2023 11:44 AM",
      total: 200.00,
      user_id: "1"
    },
   
  ];
  

  constructor() { }
}
